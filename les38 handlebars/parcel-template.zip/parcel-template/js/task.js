import { countries } from "./countries.js";

import Handlebars from "handlebars"
import templateSource  from "../src/templates/countries.hbs";

const templateCountries = Handlebars.compile(templateSource())

console.log(templateCountries());
// console.log(templateSource);

// const countriesContainer = document.querySelector('#countriesContainer').innerHTML

// countriesContainer.innerHTML = templateCountries(countries)

// document.body.innerHTML = templateCountries(countries)

const renderedHtml = countries.map(country => {
    templateCountries(country)
    console.log(templateCountries(country));
    
})
document.body.innerHTML = renderedHtml
